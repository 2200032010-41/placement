package com.example.Samyak.placement_interaction_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementInteractionSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementInteractionSystemApplication.class, args);
		System.out.println("Project Running....");
	}

}
