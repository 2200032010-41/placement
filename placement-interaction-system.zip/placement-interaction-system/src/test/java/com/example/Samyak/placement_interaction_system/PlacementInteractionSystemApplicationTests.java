package com.example.Samyak.placement_interaction_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementInteractionSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
